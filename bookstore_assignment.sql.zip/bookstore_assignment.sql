# bookstore_assignment database

CREATE TABLE books ( # Book --> books
	id INT,
	title TEXT,
	primary key(id)
) ;

CREATE TABLE book_roles (  # Note BookRole --> book_roles
	id INT,
	role TEXT,
	book_id INT,
	person_id INT,         # note that foreign keys are singular
	primary key(id)
) ;

CREATE TABLE people (  # Note Person --> people
	id INT,
	name TEXT,
	primary key(id)
) ;

CREATE TABLE address_records (
	id INT,
	address_type TEXT,  # avoid just type, has special RoR meaning
	person_id INT,
	address_id INT,
	primary key(id)
) ;

CREATE TABLE addresses (
	id INT,
	street_part TEXT,
	zip TEXT,               # Note that zip is not INT.
	primary key(id)
) ;

CREATE TABLE purchases (
	id INT,
	purchase_date DATETIME,
	person_id INT,
	primary key(id)
) ;

CREATE TABLE book_purchases (  # Required by habtm between Book and Purchase
	purchase_id INT,
	book_id INT,
	primary key(purchase_id, book_id) # note composite primary key
) ;

# A Book and its author
INSERT INTO books VALUE (12, "Jane Eyre");
INSERT INTO people VALUE (31, "Charlotte Bronte");
INSERT INTO book_roles VALUE (21, "author", 12, 31);

# An editor for that book and its editor
INSERT INTO people VALUE (35, "C. Bronte's Editor");
INSERT INTO book_roles VALUE (22, "editor", 12, 35);

# A supplier for that book
INSERT INTO people VALUE (37, "Bronte's book supplier");
INSERT INTO book_roles VALUE (23, "supplier", 12, 37);
# their address
INSERT INTO addresses VALUE (304, "1231 Bronte Street", "88838");
INSERT INTO address_records VALUE (405, "mailing", 37, 304);

# A second book, same supplier
INSERT INTO books VALUE (14, "Wuthering Heights");
INSERT INTO people VALUE (203, "Emily Bronte");
INSERT INTO book_roles VALUE (24, "author", 14, 203);
INSERT INTO book_roles VALUE (25, "supplier", 14, 37);

# A customer for both books, same billing and mailing address
INSERT INTO people VALUE (23, "Bronte customer");
INSERT INTO addresses VALUE (305, "1333 Customer Street", "88433");
INSERT INTO address_records VALUE (406, "mailing", 304, 23);
INSERT INTO address_records VALUE (407, "billing", 304, 23);

# A purchase of that book and a second
INSERT INTO purchases VALUE (2000, "2014-01-03 12:12:12", 23);
INSERT INTO book_purchases VALUE (2000, 12);
INSERT INTO book_purchases VALUE (2000, 14);








